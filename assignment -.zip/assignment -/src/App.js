import React, { useState, useMemo, useEffect } from 'react';
import './App.css';
import ProductList from './components/ProductList';
import Filters from './components/Filters';
import Cart from './components/Cart';

function App() {
  const [products, setProducts] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const [filters, setFilters] = useState({
    search: '',
    category: '',
    sort: ''
  });

  // ✅ Fetch products from given API (MANDATORY)
  useEffect(() => {
    fetch('https://dummyjson.com/products')
      .then(res => res.json())
      .then(data => {
        const normalizedProducts = data.products.slice(0, 20).map(p => ({
          id: p.id,
          name: p.title,
          price: p.price,
          category: p.category,
          stock: p.stock,
          thumbnail: p.thumbnail
        }));
        setProducts(normalizedProducts);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  // ✅ Extract categories
  const categories = useMemo(() => {
    return [...new Set(products.map(p => p.category))];
  }, [products]);

  // ✅ Filter + Sort (derived state)
  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (filters.search) {
      const query = filters.search.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(query)
      );
    }

    if (filters.category) {
      result = result.filter(p => p.category === filters.category);
    }

    if (filters.sort === 'price-low-high') {
      result.sort((a, b) => a.price - b.price);
    } else if (filters.sort === 'price-high-low') {
      result.sort((a, b) => b.price - a.price);
    }

    return result;
  }, [products, filters]);

  // ======================
  // CART LOGIC (CLEAN & HUMAN)
  // ======================

  const addToCart = (product) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);

      if (existing) {
        if (existing.quantity >= product.stock) return prev;
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }

      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId) => {
    setCartItems(prev => prev.filter(item => item.id !== productId));
  };

  const updateItemQuantity = (productId, delta) => {
    setCartItems(prev =>
      prev
        .map(item => {
          if (item.id !== productId) return item;

          const newQty = item.quantity + delta;
          if (newQty < 1) return null;
          if (newQty > item.stock) return item;

          return { ...item, quantity: newQty };
        })
        .filter(Boolean)
    );
  };

  // ======================
  // FILTER HANDLERS
  // ======================

  const onChangeFilter = (name, value) => {
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const clearFilters = () => {
    setFilters({ search: '', category: '', sort: '' });
  };

  if (loading) {
    return <p style={{ padding: 20 }}>Loading products...</p>;
  }

  return (
    <div className="App">
      <header className="app-header">
        <h1>Mini E-Commerce</h1>
      </header>

      <main className="main-layout">
        <section className="product-section">
          <Filters
            filters={filters}
            onFilterChange={onChangeFilter}
            onClearFilters={clearFilters}
            categories={categories}
          />

          <ProductList
            products={filteredProducts}
            onAddToCart={addToCart}
          />
        </section>

        <aside className="cart-section">
          <Cart
            items={cartItems}
            onIncrease={(id) => updateItemQuantity(id, 1)}
            onDecrease={(id) => updateItemQuantity(id, -1)}
            onRemove={removeFromCart}
          />
        </aside>
      </main>
    </div>
  );
}

export default App;

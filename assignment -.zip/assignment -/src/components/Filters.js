import React from 'react';

function Filters({ filters, onFilterChange, onClearFilters, categories }) {
  const handleChange = (e) => {
    const { name, value } = e.target;
    onFilterChange(name, value);
  };

  return (
    <div style={styles.container}>
      <input
        type="text"
        name="search"
        placeholder="Search products..."
        value={filters.search}
        onChange={handleChange}
        style={styles.input}
      />

      <select
        name="category"
        value={filters.category}
        onChange={handleChange}
        style={styles.select}
      >
        <option value="">All Categories</option>
        {categories.map(cat => (
          <option key={cat} value={cat}>
            {cat}
          </option>
        ))}
      </select>

      <select
        name="sort"
        value={filters.sort}
        onChange={handleChange}
        style={styles.select}
      >
        <option value="">Sort By</option>
        <option value="price-low-high">Price: Low to High</option>
        <option value="price-high-low">Price: High to Low</option>
      </select>

      <button onClick={onClearFilters} style={styles.button}>
        Clear
      </button>
    </div>
  );
}

const styles = {
  container: {
    display: 'flex',
    gap: 10,
    marginBottom: 20,
    flexWrap: 'wrap',
    padding: 15,
    backgroundColor: '#f8f9fa',
    borderRadius: 8
  },
  input: {
    flex: 2,
    padding: 8,
    borderRadius: 4,
    border: '1px solid #ddd',
    minWidth: 200
  },
  select: {
    flex: 1,
    padding: 8,
    borderRadius: 4,
    border: '1px solid #ddd',
    minWidth: 150
  },
  button: {
    padding: '8px 16px',
    backgroundColor: '#6c757d',
    color: '#fff',
    border: 'none',
    borderRadius: 4,
    cursor: 'pointer'
  }
};

export default Filters;

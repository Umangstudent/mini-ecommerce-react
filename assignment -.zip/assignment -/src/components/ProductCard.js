import React, { useState } from 'react';

function ProductCard({ product, onAddToCart }) {
  const outOfStock = product.stock === 0;

  // ✅ Hook must be at top level
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    onAddToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 800);
  };

  return (
    <div style={styles.card}>
      <div style={styles.imageContainer}>
        <img
          src={product.thumbnail}
          alt={product.name}
          style={styles.image}
        />
      </div>

      <div style={styles.info}>
        <h3 style={styles.title}>{product.name}</h3>
        <p style={styles.category}>{product.category}</p>

        <div style={styles.priceRow}>
          <span style={styles.price}>${product.price}</span>
          <span style={styles.stock}>
            {outOfStock ? 'Out of stock' : `${product.stock} in stock`}
          </span>
        </div>

        <button
          onClick={handleAdd}
          disabled={outOfStock}
          style={{
            ...styles.button,
            backgroundColor: outOfStock
              ? '#ccc'
              : added
              ? '#28a745'
              : '#007bff',
            cursor: outOfStock ? 'not-allowed' : 'pointer'
          }}
        >
          {outOfStock ? 'Out of Stock' : added ? 'Added ✓' : 'Add to Cart'}
        </button>
      </div>
    </div>
  );
}

const styles = {
  card: {
    border: '1px solid #eee',
    borderRadius: 8,
    padding: 16,
    backgroundColor: '#fff'
  },
  imageContainer: {
    height: 150,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10
  },
  image: {
    maxWidth: '100%',
    maxHeight: '100%',
    objectFit: 'contain'
  },
  info: {
    display: 'flex',
    flexDirection: 'column'
  },
  title: {
    fontSize: '1rem',
    margin: '0 0 6px 0'
  },
  category: {
    fontSize: '0.8rem',
    color: '#777',
    marginBottom: 10,
    textTransform: 'capitalize'
  },
  priceRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: 10
  },
  price: {
    fontWeight: 'bold'
  },
  stock: {
    fontSize: '0.8rem',
    color: '#555'
  },
  button: {
    padding: 10,
    border: 'none',
    borderRadius: 4,
    color: '#fff',
    marginTop: 'auto'
  }
};

export default ProductCard;

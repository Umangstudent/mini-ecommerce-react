import React from 'react';
import CartItem from './CartItem';

const Cart = React.memo(({ items, onIncrease, onDecrease, onRemove }) => {
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  if (items.length === 0) {
    return (
      <div style={styles.container}>
        <h2>Shopping Cart</h2>
        <p style={styles.empty}>Your cart is empty.</p>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <h2>Shopping Cart ({totalItems})</h2>

      <div style={styles.list}>
        {items.map(item => (
          <CartItem
            key={item.id}
            item={item}
            onIncrease={onIncrease}
            onDecrease={onDecrease}
            onRemove={onRemove}
          />
        ))}
      </div>

      <div style={styles.summary}>
        <div style={styles.totalRow}>
          <span>Total</span>
          <span style={styles.totalPrice}>${totalPrice.toFixed(2)}</span>
        </div>

        <button style={styles.checkoutButton} disabled>
          Checkout (demo)
        </button>
      </div>
    </div>
  );
});

const styles = {
  container: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 20,
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    position: 'sticky',
    top: 20
  },
  list: {
    maxHeight: 400,
    overflowY: 'auto',
    marginBottom: 20
  },
  empty: {
    textAlign: 'center',
    color: '#777',
    marginTop: 20
  },
  summary: {
    borderTop: '1px solid #eee',
    paddingTop: 15
  },
  totalRow: {
    display: 'flex',
    justifyContent: 'space-between',
    fontWeight: 'bold',
    marginBottom: 12
  },
  totalPrice: {
    color: '#007bff'
  },
  checkoutButton: {
    width: '100%',
    padding: 10,
    backgroundColor: '#ccc',
    color: '#555',
    border: 'none',
    borderRadius: 4,
    cursor: 'not-allowed'
  }
};

export default Cart;

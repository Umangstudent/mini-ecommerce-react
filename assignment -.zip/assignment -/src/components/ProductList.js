import React from 'react';
import ProductCard from './ProductCard';

const ProductList = React.memo(({ products, onAddToCart }) => {
  if (products.length === 0) {
    return (
      <div style={styles.empty}>
        <h3>No products found</h3>
        <p>Try adjusting your search or filters.</p>
      </div>
    );
  }

  return (
    <div style={styles.grid}>
      {products.map(product => (
        <ProductCard 
          key={product.id} 
          product={product} 
          onAddToCart={onAddToCart} 
        />
      ))}
    </div>
  );
});

const styles = {
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
    gap: '20px',
    padding: '20px 0'
  },
  empty: {
    textAlign: 'center',
    padding: '40px',
    color: '#666',
    backgroundColor: '#f9f9f9',
    borderRadius: '8px',
    marginTop: '20px'
  }
};

export default ProductList;

import React from 'react';

function CartItem({ item, onIncrease, onDecrease, onRemove }) {
  return (
    <div style={styles.container}>
      <div style={styles.details}>
        <h4 style={styles.title}>{item.name}</h4>
        <p style={styles.price}>
          ${item.price.toFixed(2)} × {item.quantity}
        </p>
      </div>

      <div style={styles.actions}>
        <div style={styles.quantityControls}>
          <button
            onClick={() => onDecrease(item.id)}
            style={styles.qtButton}
          >
            −
          </button>

          <span style={styles.quantity}>{item.quantity}</span>

          <button
            onClick={() => onIncrease(item.id)}
            style={styles.qtButton}
            disabled={item.quantity >= item.stock}
          >
            +
          </button>
        </div>

        <button
          onClick={() => onRemove(item.id)}
          style={styles.removeButton}
        >
          Remove
        </button>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 0',
    borderBottom: '1px solid #eee'
  },
  details: {
    flex: 1
  },
  title: {
    margin: '0 0 4px 0',
    fontSize: '0.9rem'
  },
  price: {
    margin: 0,
    color: '#555',
    fontSize: '0.85rem'
  },
  actions: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
    gap: 6
  },
  quantityControls: {
    display: 'flex',
    alignItems: 'center',
    gap: 8
  },
  qtButton: {
    width: 24,
    height: 24,
    border: '1px solid #ddd',
    backgroundColor: '#f9f9f9',
    borderRadius: 4,
    cursor: 'pointer'
  },
  quantity: {
    minWidth: 20,
    textAlign: 'center',
    fontSize: '0.9rem'
  },
  removeButton: {
    fontSize: '0.75rem',
    color: '#dc3545',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    textDecoration: 'underline',
    padding: 0
  }
};

export default CartItem;
